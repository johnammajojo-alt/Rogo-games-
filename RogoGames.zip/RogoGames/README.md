# ROGO Games (Android project)

A WebView app that bundles two games: ROGO and Puzzle Pals. Your logo is the app icon.

## Build the APK

1. Install Android Studio (free): https://developer.android.com/studio
2. Unzip this folder, then in Android Studio choose File > Open and select the `RogoGames` folder.
3. Wait for Gradle sync to finish (first time it downloads about 1 GB; internet needed).
4. Debug APK (quick test): Build > Build Bundle(s) / APK(s) > Build APK(s).
   The file appears at `app/build/outputs/apk/debug/app-debug.apk`.
5. Install: copy the APK to your phone and open it (allow "install unknown apps" when asked),
   or plug the phone in with USB debugging and press the green Run button.

## Release APK (for sharing)

Build > Generate Signed Bundle / APK > APK. Create a keystore when asked and keep it safe.

## Notes

- The games live in `app/src/main/assets/`. Edit the HTML there and rebuild to change them.
- Fonts load from Google Fonts when online; offline the games fall back to system fonts.
- To change the app name, edit `app/src/main/res/values/strings.xml`.
- To change the package name, edit `namespace` and `applicationId` in `app/build.gradle.kts`.

## No Android Studio? Build the APK online (free)

1. Create a free account at https://github.com and make a new repository.
2. Upload the contents of this folder to it (keep the `.github` folder; on the web use "Add file > Upload files").
3. Open the repository's Actions tab. The "Build APK" run starts by itself (or press Run workflow).
4. When it turns green (about 5 minutes), open the run and download `ROGO-Games-APK` under Artifacts.
5. Unzip it, send `app-debug.apk` to your phone, and install it.
