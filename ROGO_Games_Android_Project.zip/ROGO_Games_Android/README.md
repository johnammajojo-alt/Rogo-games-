# ROGO Games — Android build

This Android project wraps your two HTML games (ROGO and Puzzle Pals) in a native Android WebView app. The supplied anime logo is used as the launcher icon.

## Build the APK online with GitHub Actions

1. Create a GitHub repository.
2. Upload **all contents** of this folder to the repository root (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and run **Build APK** (or wait for the push-triggered build).
4. Open the successful workflow run and download the `ROGO-Games-APK` artifact.
5. Extract the downloaded artifact; install `app-debug.apk` on your Android phone. If prompted, allow installation from that source.

## Build with Android Studio

Open this folder in Android Studio, wait for Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.rogo.games`  
Minimum Android: 7.0 (API 24)  
App name: ROGO Games
